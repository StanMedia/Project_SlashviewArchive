﻿#利用Powershell修正Windows檔案的「建立日期」、「修改日期」、「存取日期」屬性
#Use Powershell to change Windows files CreationTime, LastWriteTime(a.k.a ModifyDate), LastAccessTime date.
# -name FileName
# -date yyyy-MM-dd HH:mm:ss datetime wanna change

param (
  [string]$name = "",
  [string]$date = ""
)

if ([string]::IsNullOrEmpty($name))
{
  Write-Host "請指定欲變更「修改日期」的檔案名稱。";
  exit;
}

$name = "$($PSScriptRoot)\$($name)";
if (!([System.IO.File]::Exists($name)))
{
  Write-Host "指定的檔案不存在。";
  exit;
}

[DateTime]$newDate = New-Object DateTime;
if ([string]::IsNullOrEmpty($date))
{
  $newDate = (Get-Date);
}
else
{
  if (!([DateTime]::TryParseExact(
    $date,
    "yyyy-MM-dd HH:mm:ss",
    [System.Globalization.CultureInfo]::InvariantCulture,
    [System.Globalization.DateTimeStyles]::None,
    [ref]$newDate)
  ))
  {
    Write-Host "欲變更的日期格式不正確。";
    exit;
  }
}

#變更檔案之「修改日期」屬性
$file = Get-Item $name;
$file.CreationTime   = $newDate;  #建立日期
$file.LastWriteTime  = $newDate;  #修改日期
$file.LastAccessTime = $newDate;  #存取日期
Write-Host "成功將「$($name)」之修改日期變更為「$($newDate.ToString("yyyy-MM-dd HH:mm:ss"))」。";