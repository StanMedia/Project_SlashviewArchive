01. 驅動程序的配置信息存放在下面註冊表中：
　　HKLM\System\CurrentControlSet\Services\RRamdisk\Parameters\
　　為什麼要用RRamdisk這個名字，因為XP SP1開始內置了一個ramdisk程序，
　　主要用於XP Embed內存運行的。

02. 參數: DiskSizeM, DiskSizeK
　　以M和K為單位的虛擬盤大小，K單位優先。

03. 參數: MediaType
　　虛擬盤模擬的磁盤類型：
　　　　1 -- 內存盤
　　　　2 -- 固定介質 (缺省)
　　　　3 -- 移動介質
　　　　4 -- 軟驅，和移動盤區別不大

04. 參數: UsePAE
　　設置為1時，允許在32位windows下使用memory remap到4G之上的內存。要求32位2k/xp/vista，4G物理內存，BIOS打開memory remap/hole。

05. 參數: DriveLetter
　　所用盤符，缺省為 R:

06. 參數: SectorsPerCluster
　　希望的簇大小, 零由驅動程序決定:
　　　　<= 2M　　　　FAT12, 簇=512
　　　　<= 32M　　　 FAT16, 簇=512
　　　　<= 64M　　　 FAT16, 簇=1k
　　　　<= 128M　　　FAT16, 簇=2k
　　　　<= 256M　　　FAT16, 簇=4k
　　　　<= 512M　　　FAT32, 簇=2k
　　　　<= 16G　　　 FAT32, 簇=4k
　　　　......
　　如果你選擇的簇大小比缺省的小，分區會被格式化成FAT32格式。

07. 參數: Image
　　由rdutil程序管理，主要用以自動加載NTFS映像. 例如:
　　1) 加載虛擬盤，不要做任何操作
　　2) 格式化為NTFS
　　　　　FORMAT /FS:NTFS /Q /V:RamDisk /A:512 R:
　　3) 把NTFS的日誌大小設到最小（2M）
　　　　　CHKDSK /L:2048 R:
　　4) 預設訪問權限（例子是只允許管理員們使用虛擬盤）
　　　　　CACLS R:\ /G: BUILTIN\Adminstrators:F
　　5) 創建一些目錄結構，如臨時目錄
　　　　　MKDIR R:\TEMP
　　6) 壓縮虛擬盤，並存到這個註冊表中
　　　　　rdutil R: registry

　　註釋:
　　1) 你應該盡量不要往虛擬盤上放太多東西，壓縮後的映像文件不能超過64K
　　2) 當你改變虛擬盤大小時必須重新創建映像文件
　　3) 當映像文件大小和虛擬盤大小不符時，虛擬盤將不再自動格式化。
　　　 如果要驅動自動格式化，必須刪除這個註冊表項。
　　　　　rdutil 程序使用示例:
　　1) 備份註冊表裡的映像文件
　　　　　rdutil save filename
　　2) 恢復註冊表裡的映像文件
　　　　　rdutil load filename
　　3) 測試壓縮映像文件大小
　　　　　rdutil R:
　　　　　rdutil registry
　　　　　rdutil unpacked_file
　　　 第二條命令壓縮註冊表裡設置的缺省盤符
　　　 第三條命令壓縮被解開的映像文件
　　4) 壓縮盤符並存入註冊表
　　　　　rdutil R: registry
　　5) 壓縮盤符但保存到文件
　　　　　rdutil R: packed_file
　　6) 把映像文件解開
　　　　　rdutil unpack packed_file unpacked_file
　　7) 創建一個NTFS符號連接直接指向虛擬盤
　　　　　rdutil link temp \

08. 重新格式化虛擬盤
　　除了內存介質類型外，其它的盤符都可以重新格式化。如：
　　固定介質
　　　　FORMAT /FS:NTFS /FORCE /Q /V:RamDisk /A:512 R:
　　移動介質
　　　　ECHO Y | FORMAT /FS:NTFS /FORCE /Q /V:RamDisk /A:512 R:
　　你可以在開機腳本裡對虛擬盤重新格式化。但不推薦再次格式化為FAT分區，
　　因為驅動程序格式化的分區比通用格式化程序效率更高。如果要把虛擬盤做
　　成映像文件作它用（特別是軟驅），推薦重新格書化為標準格式。

09. 頁面交換文件支持
　　如果你使用固定介質類型，並且不重新格式化，你可以用系統管理直接把
　　頁面文件加到虛擬盤上。 如果你使用其它介質類型，或者需要重新格式化，
　　請使用addswap程序創建頁面文件。 如：
　　　　addswap r:\pagefile.sys 16 32
　　創建一個頁面文件，最小16M，最大32M

10. TEMP 臨時目錄
　　驅動程序格式化時已經創建好了TEMP目錄。需要的話要把TEMP和TMP環境變量
　　設到子目錄下，不能設置到根目錄。

11. NTFS 符號連接到虛擬盤
　　當使用內存盤介質類型時，不能從其它NTFS分區創建符號連接到虛擬盤。
　　固定和移動介質都沒有問題。

12. Connectix VirtualPC 兼容性
　　如果VPC無法使用物理RAW磁盤時，不要使用固定介質類型。

13. 無盤符工作方式
　　把DriveLetter註冊表值設為空，驅動將不創建任何盤符。注意不是刪除
　　DriveLetter，否則缺省創建R：
　　無盤符方式下，用rdutil創建ram目錄指向虛擬盤（只能在NTFS分區裡）：
　　　　rdutil link C:\ramdisk
　　　　　連接 C:\ramdisk 到虛擬盤根目錄
　　　　rdutil link C:\TEMP TEMP
　　　　　連接 C:\TEMP 到虛擬盤的 \TEMP 下
　　　　rmdir C:\ramdisk
　　　　　rmdir 可以直接刪除連接點，不會影響連接目標
　　不推薦使用無盤符模式，因為大多是防毒程序無法實時監控無盤符的分區

ChangeLog:
01.01.2008 support >=4G ram under 32bit windows
05.23.2007 x64 support
12.09.2003 fix SMP/HT compatibility
11.26.2003 fix re-format problem & some typo
11.25.2003 merge rdpack and rdj to rdutil
11.24.2003 add DiskSizeK registry, more compatible w/ antivirus software