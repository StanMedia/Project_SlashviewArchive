﻿namespace FormDataTranslation
{
	class Global
	{
		public static Form2 oForm2;
		public static bool bHasBeenShowedForm2;
	}
}
