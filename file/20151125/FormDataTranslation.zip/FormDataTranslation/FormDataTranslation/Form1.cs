﻿namespace FormDataTranslation
{
	public partial class Form1 : System.Windows.Forms.Form
	{
		public Form1()
		{
			InitializeComponent();
		}
		private void Form1_Load(object sender, System.EventArgs e)
		{
			//這裡不用實作表初次被建立時（避免重複掛載事件）的檢查機制，因為如果此表單一關閉，那麼全部的程式也都結束了
			//當焦點到文字框時，要進行什麼樣的處理
			textBox1.GotFocus += (oS, oE) => {
				if (Global.bHasBeenShowedForm2) { return; }
				if (Global.oForm2 == null)
				{
					//建立輸入表單
					Global.oForm2 = new Form2();
					Global.oForm2.ClientSize = new System.Drawing.Size(210, 150);
					Global.oForm2.StartPosition = System.Windows.Forms.FormStartPosition.Manual;
					Global.oForm2.Location = new System.Drawing.Point(this.Location.X + this.ClientSize.Width + 2, this.Location.Y + 1);
					//為輸入表單綁上事件
					Global.oForm2.OnSending += (cTemp) => {
						switch (cTemp)
						{
							case "← 倒退鍵":
								if (textBox1.Text.Length > 0)
								{ textBox1.Text = textBox1.Text.Substring(0, textBox1.Text.Length - 1); }
								break;
							default:
								textBox1.Text += cTemp;
								break;
						}
					};
				}
				//如果輸入表單沒有顯示，那就顯示它
				if (!Global.oForm2.Visible)
				{
					Global.bHasBeenShowedForm2 = true;
					if (Global.oForm2.ShowDialog() == System.Windows.Forms.DialogResult.OK)
					{
						textBox1.Text += System.Environment.NewLine + "輸入視窗已經被關閉。";
						//退回後文字方框的文字狀態會呈現被全選，以下的程式碼用來消除此現象
						textBox1.SelectionStart = textBox1.Text.Length;
						textBox1.Select();
					}
				}
			};
			//當焦點離開文字框時，要進行什麼樣的處理
			textBox1.LostFocus += (oS, oE) => {
				if (!Global.oForm2.Visible) { Global.bHasBeenShowedForm2 = false; }
			};
			//按下按鈕清除文字
			button1.Click += (oS, oE) => { textBox1.Text = ""; };
		}
	}
}