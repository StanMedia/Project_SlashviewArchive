﻿namespace FormDataTranslation
{
	public delegate void Form2EventHandler(string cText);
	public partial class Form2 : System.Windows.Forms.Form
	{
		private bool _bIAmAlive = false;
		public event Form2EventHandler OnSending;
		public Form2()
		{
			InitializeComponent();
		}
		private void Form2_Load(System.Object sender, System.EventArgs e)
		{
			//實作類似IsPostBack，只有表單初次建立才會進入，避免事件被重複掛載，並增強效能
			if (!_bIAmAlive)
			{
				//綁定送訊息觸發事件
				button1.Click += TextButtonClick;
				button2.Click += TextButtonClick;
				button3.Click += TextButtonClick;
				//Button2設定成對話框的OK回覆鈕
				button4.DialogResult = System.Windows.Forms.DialogResult.OK;
				button4.Click += (oS, oE) => { this.Close(); };
				//將自己標示為正活著
				_bIAmAlive = true;
      }
		}
		private void TextButtonClick(System.Object sender, System.EventArgs e)
		{
			if (OnSending != null) { OnSending(((System.Windows.Forms.Button)sender).Text); }
		}
	}
}
