1. Copy this "PowerPlanToggle" folder to "C:\", or any path you like.
2. Right click "PowerPalnToggle.exe", choice options of "Pin to Start" to create shortcut on your Windows 10 start menu.
3. If you don't finish "Step 2", you might have NO effect of Windows 8/10 noticication.

※ 請注意，如果「PowerPalnToggle.exe」在你的開始選單中不存在任何捷徑，否則不會有任何通知效果彈出。